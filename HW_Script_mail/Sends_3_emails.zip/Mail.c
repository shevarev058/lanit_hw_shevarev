#include <string.h>
#include <time.h>

char *mail(size_t len)
{
 static char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789,.-#?!";
 char *randStr = NULL;
 size_t i;
 
 if (len)
 {
  randStr = (char *)malloc(sizeof(char) * (len + 1));
  if (randStr)
  {
   for (i = 0; i<len; i++)
   {
    int key = rand() % (int)(sizeof(charset) - 1);
    randStr[i] = charset[key];
   }
   randStr[i] = '\0';
  }
 }
 return randStr;
}