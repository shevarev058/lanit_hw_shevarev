send(){
	lr_start_transaction("Send_mail");
	
	lr_save_string(mail(20),"pararam");
		
	web_submit_data("compose-action.xml", 
		"Action=https://mail.yandex.ru/lite/compose-action.xml", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://mail.yandex.ru/lite/compose/retpath=", 
		"Snapshot=t502.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=request", "Value=", ENDITEM, 
		"Name=to", "Value={To_mail}, ", ENDITEM, 
		"Name=cc", "Value=", ENDITEM, 
		"Name=bcc", "Value=", ENDITEM, 
		"Name=subj", "Value={pararam}", ENDITEM, 
		"Name=send", "Value={pararam}", ENDITEM, 
		"Name=att", "Value=", "File=Yes", ENDITEM, 
		"Name=doit", "Value=Отправить", ENDITEM, 
		"Name=compose_check", "Value={compose_value}", ENDITEM, 
		"Name=_ckey", "Value={ckey_value}", ENDITEM, 
		"Name=ttype", "Value=plain", ENDITEM, 
		"Name=_handlers", "Value=do-send", ENDITEM, 
		"Name=style", "Value=lite", ENDITEM, 
		"Name=fid", "Value=", ENDITEM, 
		"Name=from_mailbox", "Value={Login}@yandex.ru", ENDITEM, 
		"Name=from_name", "Value=Парамон Еременчук", ENDITEM, 
		"Name=mark_as", "Value=", ENDITEM, 
		"Name=mark_ids", "Value=", ENDITEM, 
		"Name=retpath", "Value=inbox", ENDITEM, 
		"Name=nohl", "Value=", ENDITEM, 
		LAST);
	


	lr_end_transaction("Send_mail",LR_AUTO);
}