Action()
{
	int i;
	
	lr_start_transaction("Scrip_one");
	
	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_reg_find("Text=Авторизация", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");


	web_reg_save_param_regexp(
		"ParamName=value_token_login",
		"RegExp=name=\"csrf_token\" value=\"(.+?)\"",
		"Group=1",
		"Ordinal=1",
		SEARCH_FILTERS,
		LAST);

	web_reg_save_param_regexp(
		"ParamName=process",
		"RegExp=process_uuid=(.+?)\"",
		"Group=1",
		"Ordinal=1",
		SEARCH_FILTERS,
		LAST);

	

	web_url("lite", 
		"URL=https://mail.yandex.ru/lite", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t460.inf", 
		"Mode=HTML", 
		LAST);


	lr_start_transaction("Login");


	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");


	web_reg_save_param_regexp(
		"ParamName=track",
		"RegExp=\"track_id\":\"(.+?)\"",
		"Group=1",
		"Ordinal=1",
		SEARCH_FILTERS,
		LAST);

	web_submit_data("start", 
		"Action=https://passport.yandex.ru/registration-validations/auth/multi_step/start", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://passport.yandex.ru/auth?mode=auth&retpath=http%3A%2F%2Fmail.yandex.ru%2Flite", 
		"Snapshot=t471.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=csrf_token", "Value={value_token_login}", ENDITEM, 
		"Name=login", "Value={Login}", ENDITEM, 
		"Name=process_uuid", "Value={process}", ENDITEM, 
		"Name=retpath", "Value=http://mail.yandex.ru/lite", ENDITEM, 
		LAST);

	lr_end_transaction("Login",LR_AUTO);


	lr_start_transaction("Password");


	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_submit_data("commit_password", 
		"Action=https://passport.yandex.ru/registration-validations/auth/multi_step/commit_password", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://passport.yandex.ru/auth/welcome?mode=auth&retpath=http%3A%2F%2Fmail.yandex.ru%2Flite", 
		"Snapshot=t478.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=csrf_token", "Value={value_token_login}", ENDITEM, 
		"Name=track_id", "Value={track}", ENDITEM, 
		"Name=password", "Value={Password}", ENDITEM, 
		"Name=retpath", "Value=http://mail.yandex.ru/lite", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_reg_save_param_regexp(
		"ParamName=rf_pass",
		"RegExp=csrf\":\"(.+?)\"",
		"Group=1",
		"Ordinal=1",
		SEARCH_FILTERS,
		LAST);

	
	
	web_submit_data("accounts", 
		"Action=https://passport.yandex.ru/registration-validations/auth/accounts", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://passport.yandex.ru/auth/welcome?mode=auth&retpath=http%3A%2F%2Fmail.yandex.ru%2Flite", 
		"Snapshot=t480.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=csrf_token", "Value={value_token_login}", ENDITEM, 
		LAST);

	web_submit_data("ask_v2", 
		"Action=https://passport.yandex.ru/registration-validations/auth/additional_data/ask_v2", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://passport.yandex.ru/auth/welcome?mode=auth&retpath=http%3A%2F%2Fmail.yandex.ru%2Flite", 
		"Snapshot=t481.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=csrf_token", "Value={rf_pass}", ENDITEM, 
		"Name=uid", "Value=1428957757", ENDITEM, 
		LAST);

	
	

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_custom_request("16082914_2", 
		"URL=https://mc.yandex.ru/clmap/16082914?page-url=https%3A%2F%2Fmail.yandex.ru%2Flite&pointer-click=rn%3A721709535%3Ax%3A15154%3Ay%3A30583%3At%3A95%3Ap%3AN%3BWAAFA1A1A%3AX%3A229%3AY%3A68&browser-info=gdpr%3A13-0%3Au%3A1622290348883568376%3Av%3A530%3Avf%3Abx1nzewshyqnl6m%3Arqnl%3A1%3Ati%3A0%3Ast%3A1622290386&force-urlencoded=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t489.inf", 
		"EncType=text/plain;charset=UTF-8", 
		LAST);

	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_reg_save_param_regexp(
		"ParamName=compose_value",
		"RegExp=compose_check\" value=\"(.+?)\"",
		"Group=1",
		"Ordinal=1",
		SEARCH_FILTERS,
		LAST);

	web_reg_save_param_regexp(
		"ParamName=ckey_value",
		"RegExp=_ckey\" value=\"(.+?)\"",
		"Group=1",
		"Ordinal=1",
		SEARCH_FILTERS,
		LAST);


	web_url("retpath=", 
		"URL=https://mail.yandex.ru/lite/compose/retpath=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://mail.yandex.ru/lite", 
		"Snapshot=t490.inf", 
		"Mode=HTML", 
		LAST);


	lr_end_transaction("Password",LR_AUTO);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");
	
	for(i=0; i<=2; i++){
		
		send();
	
	}

	lr_start_transaction("log0ut");


	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");


	web_url("passport", 
		"URL=https://passport.yandex.ru/passport?mode=logout&yu=312511831622290344&retpath=https%3A%2F%2Fyandex.ru", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t510.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("log0ut",LR_AUTO);
	
	lr_end_transaction("Scrip_one",LR_AUTO);


	return 0;
}