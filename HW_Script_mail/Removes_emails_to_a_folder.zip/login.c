func(){
	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");
	

	web_reg_save_param_regexp(
		"ParamName=track",
		"RegExp=track_id\":\"(.+?)\"",
		"Group=1",
		"Ordinal=1",
		SEARCH_FILTERS,
		LAST);


	web_submit_data("start", 
		"Action=https://passport.yandex.ru/registration-validations/auth/multi_step/start", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://passport.yandex.ru/auth?mode=auth&retpath=http%3A%2F%2Fmail.yandex.ru%2Flite", 
		"Snapshot=t80.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=csrf_token", "Value={token_logpass}", ENDITEM, 
		"Name=login", "Value={Login}", ENDITEM, 
		"Name=process_uuid", "Value={proc_id}", ENDITEM, 
		"Name=retpath", "Value=http://mail.yandex.ru/lite", ENDITEM, 
		LAST);
}