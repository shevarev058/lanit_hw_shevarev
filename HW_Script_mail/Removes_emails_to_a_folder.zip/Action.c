Action()
{

int i;
char *check;
	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_reg_find("Text=Авторизация", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");


	web_add_auto_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"90\", \"Google Chrome\";v=\"90\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_reg_save_param_regexp(
		"ParamName=token_logpass",
		"RegExp=csrf_token\" value=\"(.+?)\"",
		"Group=1",
		"Ordinal=1",
		SEARCH_FILTERS,
		LAST);

	web_reg_save_param_regexp(
		"ParamName=proc_id",
		"RegExp=process_uuid=(.+?)\"",
		"Group=1",
		"Ordinal=1",
		SEARCH_FILTERS,
		LAST);

	
	
	web_url("lite", 
		"URL=https://mail.yandex.ru/lite", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t69.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("Login");


	func();

	lr_end_transaction("Login",LR_AUTO);

	lr_start_transaction("password");


	password();
	
	lr_end_transaction("password",LR_AUTO);
	
	
	for(i=0; i<1; i++){
		web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	
	
	web_reg_save_param_regexp(
		"ParamName=ckey",
		"RegExp=_ckey\" value=\"(.+?)\"",
		"Group=1",
		"Ordinal=1",
		SEARCH_FILTERS,
		LAST);

	web_reg_save_param_regexp(
		"ParamName=checkbox",
		"RegExp=b-form-checkbox\" value=\"(.+?)\"",
		"Group=1",
		"Ordinal=all",
		SEARCH_FILTERS,
		LAST);

	

	
	
	web_url("redirect", 
		"URL=https://passport.yandex.ru/redirect?url=http%3A%2F%2Fmail.yandex.ru%2Flite", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t92.inf", 
		"Mode=HTML", 
		LAST);

	check = lr_paramarr_random("checkbox");
	if(check){

	lr_save_string(check, "da");
	

	
	lr_start_transaction("Mail_read");

	
	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");
	
	web_reg_save_param_regexp(
		"ParamName=ckey_2",
		"RegExp=_ckey\" value=\"(.+?)\"",
		"Group=1",
		"Ordinal=1",
		SEARCH_FILTERS,
		LAST);

	web_submit_data("messages-action.xml", 
		"Action=https://mail.yandex.ru/lite/messages-action.xml", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://mail.yandex.ru/lite", 
		"Snapshot=t102.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=mark", "Value=Прочитано", ENDITEM, 
		"Name=request", "Value=", ENDITEM, 
		"Name=_ckey", "Value={ckey}", ENDITEM, 
		"Name=_handlers", "Value=do-messages", ENDITEM, 
		"Name=retpath", "Value=", ENDITEM, 
		"Name=ids", "Value={da}", ENDITEM, 
		LAST);


	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_revert_auto_header("Origin");

	web_add_auto_header("Origin", 
		"https://mail.yandex.ru");
	

	web_reg_save_param_regexp(
		"ParamName=ckey_3",
		"RegExp=_ckey\" value=\"(.+?)\"",
		"Group=1",
		"Ordinal=1",
		SEARCH_FILTERS,
		LAST);

	
	
	web_submit_data("messages-action.xml_2", 
		"Action=https://mail.yandex.ru/lite/messages-action.xml", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://mail.yandex.ru/lite/?executed_action=mark&count=1&", 
		"Snapshot=t112.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=more", "Value=Ещё…", ENDITEM, 
		"Name=request", "Value=", ENDITEM, 
		"Name=_ckey", "Value={ckey_2}", ENDITEM, 
		"Name=_handlers", "Value=do-messages", ENDITEM, 
		"Name=retpath", "Value=/", ENDITEM, 
		"Name=ids", "Value={da}", ENDITEM, 
		LAST);


	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	
	web_submit_data("message-menu-action.xml", 
		"Action=https://mail.yandex.ru/lite/message-menu-action.xml", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://mail.yandex.ru/lite/message-menu?retpath=%2F&tids=&ids=175921860444160002&count=1&lids=&", 
		"Snapshot=t123.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_ckey", "Value={ckey_3}", ENDITEM, 
		"Name=ids", "Value={da}", ENDITEM, 
		"Name=_handlers", "Value=do-messages", ENDITEM, 
		"Name=retpath", "Value=/", ENDITEM, 
		"Name=count", "Value=1", ENDITEM, 
		"Name=folder_retpath", "Value=", ENDITEM, 
		"Name=delete_retpath", "Value=", ENDITEM, 
		"Name=movefile", "Value=7", ENDITEM, 
		"Name=lid", "Value=", ENDITEM, 
		"Name=move", "Value=Выполнить", ENDITEM, 
		LAST);
	
	lr_end_transaction("Mail_read",LR_AUTO);
	}
	
	else{
	
	lr_output_message("письма закончились!!!");
	}
	}

	lr_start_transaction("Log_out");


	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");


	web_url("passport", 
		"URL=https://passport.yandex.ru/passport?mode=logout&yu=687075651622369978&retpath=https%3A%2F%2Fyandex.ru", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t131.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Log_out",LR_AUTO);

	

	return 0;
}