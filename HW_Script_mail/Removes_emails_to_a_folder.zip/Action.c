Action()
{

int i;
	web_reg_find("Text=Авторизация", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");


	web_add_auto_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"90\", \"Google Chrome\";v=\"90\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_reg_save_param_regexp(
		"ParamName=token_logpass",
		"RegExp=csrf_token\" value=\"(.+?)\"",
		"Group=1",
		"Ordinal=1",
		SEARCH_FILTERS,
		LAST);

	web_reg_save_param_regexp(
		"ParamName=proc_id",
		"RegExp=process_uuid=(.+?)\"",
		"Group=1",
		"Ordinal=1",
		SEARCH_FILTERS,
		LAST);

	
	
	web_url("lite", 
		"URL=https://mail.yandex.ru/lite", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t69.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("Login");


	func();

	lr_end_transaction("Login",LR_AUTO);

	lr_start_transaction("password");


	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_submit_data("commit_password", 
		"Action=https://passport.yandex.ru/registration-validations/auth/multi_step/commit_password", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://passport.yandex.ru/auth/welcome?mode=auth&retpath=http%3A%2F%2Fmail.yandex.ru%2Flite", 
		"Snapshot=t87.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=csrf_token", "Value={token_logpass}", ENDITEM, 
		"Name=track_id", "Value={track}", ENDITEM, 
		"Name=password", "Value=321aA111", ENDITEM, 
		"Name=retpath", "Value=http://mail.yandex.ru/lite", ENDITEM, 
		LAST);
	
	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_reg_save_param_regexp(
		"ParamName=rf_token",
		"RegExp=csrf\":\"(.+?)\"",
		"Group=1",
		"Ordinal=1",
		SEARCH_FILTERS,
		LAST);

	web_submit_data("accounts", 
		"Action=https://passport.yandex.ru/registration-validations/auth/accounts", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://passport.yandex.ru/auth/welcome?mode=auth&retpath=http%3A%2F%2Fmail.yandex.ru%2Flite", 
		"Snapshot=t89.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=csrf_token", "Value={token_logpass}", ENDITEM, 
		LAST);

	web_submit_data("ask_v2", 
		"Action=https://passport.yandex.ru/registration-validations/auth/additional_data/ask_v2", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://passport.yandex.ru/auth/welcome?mode=auth&retpath=http%3A%2F%2Fmail.yandex.ru%2Flite", 
		"Snapshot=t90.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=csrf_token", "Value={rf_token}", ENDITEM, 
		"Name=uid", "Value=1430627589", ENDITEM, 
		LAST);
	for(i=0; i<=2; i++){
		read();
	}
	lr_output_message("письма закончились!!!");


	lr_end_transaction("Mail_read",LR_AUTO);

	lr_start_transaction("Log_out");


	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");


	web_url("passport", 
		"URL=https://passport.yandex.ru/passport?mode=logout&yu=687075651622369978&retpath=https%3A%2F%2Fyandex.ru", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://mail.yandex.ru/", 
		"Snapshot=t131.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Log_out",LR_AUTO);

	

	return 0;
}