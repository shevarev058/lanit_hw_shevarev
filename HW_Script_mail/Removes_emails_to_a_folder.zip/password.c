password(){
web_add_auto_header("Sec-Fetch-Site",
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_submit_data("commit_password", 
		"Action=https://passport.yandex.ru/registration-validations/auth/multi_step/commit_password", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://passport.yandex.ru/auth/welcome?mode=auth&retpath=http%3A%2F%2Fmail.yandex.ru%2Flite", 
		"Snapshot=t87.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=csrf_token", "Value={token_logpass}", ENDITEM, 
		"Name=track_id", "Value={track}", ENDITEM, 
		"Name=password", "Value={Password}", ENDITEM, 
		"Name=retpath", "Value=http://mail.yandex.ru/lite", ENDITEM, 
		LAST);
	
	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_reg_save_param_regexp(
		"ParamName=rf_token",
		"RegExp=csrf\":\"(.+?)\"",
		"Group=1",
		"Ordinal=1",
		SEARCH_FILTERS,
		LAST);

	web_submit_data("accounts", 
		"Action=https://passport.yandex.ru/registration-validations/auth/accounts", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://passport.yandex.ru/auth/welcome?mode=auth&retpath=http%3A%2F%2Fmail.yandex.ru%2Flite", 
		"Snapshot=t89.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=csrf_token", "Value={token_logpass}", ENDITEM, 
		LAST);

	web_submit_data("ask_v2", 
		"Action=https://passport.yandex.ru/registration-validations/auth/additional_data/ask_v2", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://passport.yandex.ru/auth/welcome?mode=auth&retpath=http%3A%2F%2Fmail.yandex.ru%2Flite", 
		"Snapshot=t90.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=csrf_token", "Value={rf_token}", ENDITEM, 
		"Name=uid", "Value=1430627589", ENDITEM, 
		LAST);
}